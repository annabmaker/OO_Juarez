/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vetorcliente;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class VetorCliente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
      String[] campos = {"Nome","CPF","Celular", "Idade", "Endereço", "Estado" , "Cidade", "CEP"};
      String [] respostas = new String [campos.length];
       
      for(int i = 0; i < campos.length; i++ ){
          respostas[i] = JOptionPane.showInputDialog ("Digite  " + campos[i] + ":");
          
      }
         System.out.println("Informações do Cliente:");
        for (int i = 0; i < campos.length; i++) {
            System.out.println(campos[i] + ": " + respostas[i]);
        }
    }
    
}
   
