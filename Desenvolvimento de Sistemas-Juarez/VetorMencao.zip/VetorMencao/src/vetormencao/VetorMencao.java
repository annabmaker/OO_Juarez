/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vetormencao;

import javax.swing.JOptionPane;

/**
 *
 * @author Aluno CA
 */
public class VetorMencao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           String[] campos = {"MB- Muito Bom","B- Bom","R- Regular", "I - Irregular"};
      String [] respostas = new String [campos.length];
       
      for(int i = 0; i < campos.length; i++ ){
          respostas[i] = JOptionPane.showInputDialog ("Qual sua Menção?" + campos[i] + ":");
          
      }
         System.out.println("Digite sua menção");
        for (int i = 0; i < campos.length; i++) {
            System.out.println(campos[i] + ": ");
        }
    }
    
}
   
    
    

